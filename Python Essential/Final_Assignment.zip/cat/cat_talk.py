#!/usr/bin/env python3
import cat_say
def main():
    cat_say.______('Feed me.')  #fill the balnk
    cat_say.______('Pet me.')    #filll the blank 
    cat_say.______('Purr. Purr.')  #fill the blank
    # let the cat say GoodBye
if __name__ == '__main__':
    main()
