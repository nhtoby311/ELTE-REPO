'''
1-
Create a program that opens file.txt. Read each line of the file and prepend it with a line
number.
The contents of files.txt:
This is line one.
This is line two.
Finally, we are on the third and last line of the file.


Sample output:
1: This is line one.
2: This is line two.
3: Finally, we are on the third and last line of the file.
'''

'''
2-
Read the contents of animals.txt and produce a file named animalssorted.
txt that is sorted
alphabetically.
The contents of animals.txt:
man
bear
pig
cow
duck
horse
dog

After the program is executed the contents of animalssorted.
txt should be:
bear
cow
dog
duck
horse
man
pig
LinuxTrainingAcademy
'''

with open('file.txt') as file:
    line_number = 1
    for line in file:
        #put your code here (Hint: use print .format form )
        print('{}'.format(line))
        line_number += 1

#2        
unsorted_file_name = 'animals.txt'
sorted_file_name = 'animals-sorted.txt'
animals = []
try:
    with open(unsorted_file_name) as animals_file:
        for line in animals_file:
            animals.append(line)
    animals.sort()
except:
    print('Could not open {}.'.format(unsorted_file_name))
try:
    with open(sorted_file_name, 'w') as animals_sorted_file:
        for animal in animals:
            animals_sorted_file.write(animal)
except:
    print('Could not open {}.'.format(sorted_file_name))
