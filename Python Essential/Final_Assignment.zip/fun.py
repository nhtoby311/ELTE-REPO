'''
Create a fill in the blank word game. Prompt the user to enter a noun, verb, and an adjective.
Use those responses to fill in the blanks and display the story.
Write a short story. Remove a noun, verb, and an adjective.
Create a function to get the input from the user.
Create a function that fills in the blanks in the story you created.
Ensure each function contains a docstring.
After the noun, verb, and adjective have been collected from the user, display the story using
their input.
'''

#!/usr/bin/env python3
def get_word(word_type):
    """Get a word from a user and return that word."""
    # The lower() function converts the string to lowercase before testing it
    if word_type.lower() == 'adjective':
        # Use 'an' in front of 'adjective'
        a_or_an = 'an'
    else:
        #Otherwise, use 'a' in front of 'noun' or 'verb'
        a_or_an = 'a'
    return input('Enter a word that is {0} {1}: '.format(a_or_an, word_type))
def fill_in_the_blanks(noun, verb, adjective):
    """Fills in the blanks and returns a completed story."""
    # The \ lets the string continue on the next line to make the code easier to read
    story = "In this course you will learn how to {1}. " \
        "It's so easy even a {0} can do it. " \
        "Trust me, it will be very {2}.".format(noun, verb, adjective)
    return story
def display_story(story):
    """Displays a story."""
    print()
    print('Here is the story you created. Enjoy!')
    print()
    print(story)
def create_story():
    """Creates a story by capturing the input and displaying a finished story."""
    noun = #call the correct function with parameter(s) if needed
    verb = #call the correct function with parameter(s) if needed
    adjective = #call the correct function with parameter(s) if needed
    the_story = #call the correct function with parameter(s) if needed
    display_story(the_story)
create_story()


# I dont understand the description ....