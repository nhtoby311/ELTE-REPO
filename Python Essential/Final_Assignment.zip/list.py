'''
Create a Python program that captures and displays a person's todo
list. Continually prompt
the user for another item until they enter a blank item. After all the items are entered, display the
todo
list back to the user.


Sample Output:
Enter a task for your todo
list. Press <enter> when done: Buy cat
food.
Task added.
Enter a task for your todo
list. Press <enter> when done: Mow the
lawn.
Task added.
Enter a task for your todo
list. Press <enter> when done: Take
over the world.
Task added.
Enter a task for your todo
list. Press <enter> when done:
Your ToDo
List:
Buy
cat food.
Mow the lawn.
Take over the world.
'''

#!/usr/bin/env python3
# Create a list to hold the to-do tasks.
to_do_list = []
finished = False # put the correct word
while not finished:
    task = input('Enter a task for your to-do list. Press <enter> when done: ')
    if len(task) == 0: # finish the code lin
        finished = True
    else:
        to_do_list.append(task)
        print('Task added.')
# Display the to-do list.
print()
print('Your To-Do List:')
print('-' * 16)
for task in to_do_list:
    print(task)
