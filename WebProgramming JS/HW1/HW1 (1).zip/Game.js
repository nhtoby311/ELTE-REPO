const nameOfPlayer = localStorage.getItem("nameOfPlayer");
const numberOfPlayer = localStorage.getItem("numberOfPlayer");
const GameMode = localStorage.getItem("mode");
console.log("Game Mode: ",GameMode);
console.log("Number of player : ",numberOfPlayer);

var PlayersNames = JSON.parse(Players);
const cardWidth = 250;
const cardHeight = 100;
let checkIfASet = false;
let checkIfGameEnd = false;

// Card properties
var number = [1, 2, 3];
var shading = ['solid', 'striped', 'outlined shape'];
var color = ['red', 'purple', 'green'];
var shape = ['oval', 'squiggle', 'diamond'];

//Generate deck of card which has 27 cards
function getPracticeDeck(){
    var card_deck = [];
    for (var i = 0; i < number.length; i++) {
        for (var k = 0; k< color.length; ++k){
            for ( var l = 0; l<shape.length; ++l){
                card_deck.push({ number: number[i], shading: shading[0], color: color[k], shape: shape[l] });
            }
        }
    }
    return card_deck;
}

// Generate deck of card which has 81 cards
function getCompetitiveDeck(){
    var card_deck = [];
    for (var i = 0; i < number.length; i++) {
        for ( var j = 0; j < shading.length; ++j){
            for (var k = 0; k< color.length; ++k){
                for ( var l = 0; l<shape.length; ++l){
                    card_deck.push({ number: number[i], shading: shading[j], color: color[k], shape: shape[l] });
                }
            }
        }
    }
    return card_deck;
}

function generateDeck(GameMode){
    if (GameMode == "Competitive"){
        return  getCompetitiveDeck();
    } else {
        return  getPracticeDeck();
    }
}

// Suffle cards and choose randomly 12 cards
function PickOneCard(card_deck) {
    if (card_deck.length > 0 ){
        var r = Math.floor(Math.random() * card_deck.length);
        var temp = card_deck[r];
        card_deck.splice(r,1);
        return temp;
    } else {
        checkIfGameEnd = true;
        return null;
    }
}

var card_deck = generateDeck(GameMode);
// Choose randomly 3x4 cards based on input mode and print to console
var check_good_deck = false;
function createGame(GameMode){
    var card_UI=[
        [PickOneCard(card_deck),PickOneCard(card_deck),PickOneCard(card_deck)],
        [PickOneCard(card_deck),PickOneCard(card_deck),PickOneCard(card_deck)],
        [PickOneCard(card_deck),PickOneCard(card_deck),PickOneCard(card_deck)],
        [PickOneCard(card_deck),PickOneCard(card_deck),PickOneCard(card_deck)]
    ];
    var deck_1=[];
    var deck_2=[];
    var deck_3=[];
    for (let i = 0; i< card_UI.length; ++i){
        for (let j = 0; j < card_UI[i].length; ++j){
            deck_1.push(card_UI[i][j]);
            deck_2.push(card_UI[i][j]);
            deck_3.push(card_UI[i][j]);
        }
    }
    for (let i = 0; i< deck_1.length; ++i){
        for (let j = 0; j < deck_2.length; ++j){
            for (let k = 0 ; k< deck_3.length; ++k){
                if (checkGoodSet(deck_1[i],deck_2[j],deck_3[k])&&(i != j)&&(j != k)&&(i != k)){
                    check_good_deck = true;                   
                }
            }
        }
    }

    if (check_good_deck){
        return card_UI;
    } else {
        card_deck = generateDeck(GameMode);
        createGame(GameMode);
    }
    return card_UI;
}

var card_UI = createGame(GameMode);
PrintCardToConsole(card_UI);

// Render, timer and players
let card_Position = [];
let cnt = 0;
let start=Date.now();
let chosed_Card = [];

const canvas = document.querySelector('canvas');
const context = canvas.getContext('2d');
context.clearRect(0,0, canvas.width, canvas.height);

let players_score = {
    x : canvas.width - 262,
    y : canvas.height - 680,
    score : 0,
    name: nameOfPlayer
}

let homeBtn = {
    x: canvas.width - 255,
    y: canvas.height - 72,
    w: 60,
    h: 30
}

let resetBtn = {
    x: canvas.width - 150,
    y: canvas.height - 72,
    w: 60,
    h: 30
}

context.fillStyle = '#81b0f7'; 
context.fillRect(homeBtn.x, homeBtn.y, homeBtn.w, homeBtn.h); 
context.font = "17px serif";
context.fillStyle = 'black';
context.fillText("HOME",homeBtn.x+5,homeBtn.y+19);

context.fillStyle = '#81b0f7'; 
context.fillRect(resetBtn.x, resetBtn.y, resetBtn.w, resetBtn.h); 
context.font = "17px serif";
context.fillStyle = 'black';
context.fillText("RESET",resetBtn.x+5,resetBtn.y+19);

for (let i= 0; i<PlayersNames.length; i++){
    context.font = "30px serif"; 
    context.fillStyle = "#000000";
    context.fillText(i + 1 + ". " +PlayersNames[i].name +" : "+PlayersNames[i].score, players_score.x , players_score.y);
    players_score.y = players_score.y + 35;
}

let countDown=10;
if (GameMode == "Competitive"){

    var t = setInterval(function() {
        countDown -= 1;
        if (countDown < 0) {
        countDown = 10;
        players_score.score -= 1;
        }
    }, 1000);
}else{};
function render () {
    requestAnimationFrame(render);                              
    context.clearRect(0,0, canvas.width - 270, canvas.height);
    //Frame
    context.font = "50px serif"; 
    context.strokeStyle = "#f7258e";
    context.strokeText("Player Score", canvas.width - 262 , canvas.height - 720);

    context.font = "70px serif"; 
    context.fillStyle = "#000000";
    context.fillText("Is it a SET?", canvas.width - 1000 , canvas.height - 300);

    context.font = "22px serif"; 
    context.fillStyle = "#000000";
    context.fillText("1. Select 3 cards to try to get a SET (+/- 1 for good/bad SET)", canvas.width - 1000 , canvas.height - 260);

    context.font = "22px serif"; 
    context.fillStyle = "#000000";
    context.fillText("2. Click again on the selected cards to unselect it", canvas.width - 1000 , canvas.height - 230);

    context.font = "22px serif"; 
    context.fillStyle = "#000000";
    context.fillText("3. You get -1 for each time timer count to 0", canvas.width - 1000 , canvas.height - 200);

    context.font = "70px serif"; 
    context.fillStyle = "#000000";
    context.fillText(players_score.name+" : "+players_score.score, canvas.width - 1000 , canvas.height - 120);

    context.beginPath();
    context.moveTo(canvas.width-270, 0);
    context.lineTo(canvas.width -270 , canvas.height);
    context.strokeStyle = 'black';
    context.stroke();

    context.beginPath();
    context.moveTo(0, canvas.height - 365);
    context.lineTo(canvas.width -270 , canvas.height - 365 );
    context.strokeStyle = 'black';
    context.stroke();

    if (GameMode == "Competitive"){
    context.font = "25px serif"; 
    context.fillStyle = "#000000";
    context.fillText("Time left until next SET: "+countDown, canvas.width - 1000 , canvas.height - 50);
    }
    //Timer countup 
    let seconds=Math.floor((Date.now()-start)/1000);
    let minutes=Math.floor(seconds/60);
    seconds%=60;
    context.font = "25px serif"; 
    context.fillStyle = "#000000";
    context.fillText("Time Spent: "+minutes.toString().padStart(2,"0")+":"+seconds.toString().padStart(2,"0"), canvas.width - 500 , canvas.height - 50);

    RenderCards(card_UI);

    if (checkIfASet){
        context.font = "70px serif"; 
        context.fillStyle = "#4dfa43";
        context.fillText("YES", canvas.width - 550 , canvas.height - 300);
    } else {
        context.font = "70px serif"; 
        context.fillStyle = "#fc4e63";
        context.fillText("NO", canvas.width - 550 , canvas.height - 300);
    }
    
    
    if (checkIfGameEnd) {
        context.clearRect(0,0, canvas.width, canvas.height);
        context.font = "90px serif"; 
        context.fillStyle = "#000000";
        context.fillText("GAME OVER !", canvas.width - 800 , canvas.height - 430);

        context.font = "60px serif"; 
        context.fillStyle = "#000000";
        context.fillText("Score: "+players_score.score, canvas.width - 800 , canvas.height - 300);

        card_UI=[];
        card_deck=[];
    }
}
render();

function RenderCards(card_UI){
    for ( let i = 0; i< card_UI.length; ++i){                    //render bricks
        for (let j = 0 ; j < card_UI[i].length; ++j){
            const card = card_UI[i][j];        
            const x = j * cardWidth;
            const y = i * cardHeight;
            if (cnt < 12){
                card_Position.push([x,x+cardWidth,y,y+cardHeight]);
            }
            if (card){
                context.fillStyle = "#f0eded";
                context.fillRect(x+5, y+5, cardWidth - 2 ,cardHeight -2 );                               
                if (card_UI[i][j].shape === 'diamond') {
                    drawDiamond(context, card_UI[i][j].number, card_UI[i][j].color,card_UI[i][j].shading,x+125,y+30);
                }
                else if (card_UI[i][j].shape === 'oval'){
                    drawOval(context, card_UI[i][j].number, card_UI[i][j].color,card_UI[i][j].shading,x+110,y+15);
                } 
                else if (card_UI[i][j].shape === 'squiggle'){
                    drawSquiggle(context, card_UI[i][j].number, card_UI[i][j].color,card_UI[i][j].shading,x+100,y+45);
                }                                      
            }
        }
    }
}

//handle Canvas Click
document.getElementById('canvasID').addEventListener('click',function(event){
    if (checkIfGameEnd) event.preventDefault();
    mouseX = event.clientX;
    mouseY = event.clientY;
    let checkHit = true;
    let pos = 0;
    // Detect card and Games Logic
    try{
    while (checkHit){
        if (mouseX >= card_Position[pos][0] && mouseX <= card_Position[pos][1] && mouseY >= card_Position[pos][2] && mouseY <=card_Position[pos][3] ){ // detect card on click
            let i = 0;
            let j = 0;
            if (pos <=2 ){
                i = 0;
                j = pos;
            } else if (pos>2 && pos<=5) {
                i = 1;
                j = pos-3;
            } else if (pos>5 && pos<= 8){
                i = 2;
                j = pos-6;
            } else if (pos>8 && pos<=11){
                i = 3;
                j = pos-9;
            }
            //console.log("card: ",pos,"number: ",card_UI[i][j].number," shading: ",card_UI[i][j].shading," color: ",card_UI[i][j].color," shape: ",card_UI[i][j].shape);
            let checkSelected = false;
            let position;

            for (let k = 0; k< chosed_Card.length; k++){
                if ((chosed_Card[k].number == card_UI[i][j].number)&&(chosed_Card[k].shading == card_UI[i][j].shading)&&(chosed_Card[k].color == card_UI[i][j].color)&&(chosed_Card[k].shape == card_UI[i][j].shape)){
                    position = k;
                    checkSelected = true;
                } else {
                }
            }
            if (checkSelected) chosed_Card.splice(position, 1);
            else {
                chosed_Card.push(card_UI[i][j]);
            }
            console.log(chosed_Card.length+" cards selected");

            // Chosed cards logic
            if (chosed_Card.length == 3){
                if (checkGoodSet(chosed_Card[0],chosed_Card[1],chosed_Card[2])){
                    checkIfASet = true;
                    players_score.score +=1;
                    console.log("Found a SET: ",chosed_Card);
                    DeleteCard (chosed_Card,card_UI);
                    countDown=10;
                    chosed_Card = [];
                }
                else {
                    checkIfASet = false;
                    countDown=10;
                    players_score.score -=1;
                    ReplaceCard (chosed_Card,card_UI,card_deck);
                    chosed_Card=[];
                }
            }
            checkHit = false;
        } else {
            pos+=1;
        }
    }
    } catch(error){
        if ( 
            mouseX > homeBtn.x &&  
            mouseX < homeBtn.x + homeBtn.w && 
            mouseY > homeBtn.y &&  
            mouseY < homeBtn.y + homeBtn.h
        ) { 
            window.location = "index.html";
        }
        if ( 
            mouseX > resetBtn.x &&  
            mouseX < resetBtn.x + resetBtn.w && 
            mouseY > resetBtn.y &&  
            mouseY < resetBtn.y + resetBtn.h
        ) { 
            window.location = "Game.html";
        }
    }
});

function checkGoodSet (card1,card2,card3){
    if ((card1.shape == card2.shape)&&(card1.shape == card3.shape)
        &&(card1.number == card2.number)&&(card1.number == card3.number)
        &&(card1.color == card2.color)&&(card1.color == card3.color)
        &&(card1.shading != card2.shading)&&(card2.shading != card3.shading)&&(card2.shading != card3.shading)){
            return true;
        }
    else if ((card1.shading == card2.shading)&&(card1.shading == card3.shading)
        &&(card1.shape != card2.shape)&&(card2.shape != card3.shape)&&(card1.shape != card3.shape)
        &&(card1.color != card2.color)&&(card2.color != card3.color)&&(card1.color != card3.color)
        &&(card1.number != card2.number)&&(card2.number != card3.number)&&(card1.number != card3.number)){
            return true;
        }
    else if ((card1.shape != card2.shape)&&(card2.shape != card3.shape)&&(card1.shape != card3.shape)
        &&(card1.color != card2.color)&&(card2.color != card3.color)&&(card1.color != card3.color)
        &&(card1.number != card2.number)&&(card2.number != card3.number)&&(card1.number != card3.number)
        &&(card1.shading != card2.shading)&&(card2.shading != card3.shading)&&(card1.shading != card3.shading)){
            return true;
        }
    else if ((card1.shape == card2.shape)&&(card2.shape == card3.shape)&&(card1.shape == card3.shape) // for easier to check if its a SET (same shape ,color,shade, different number - not in the game's rule)
        &&(card1.color == card2.color)&&(card2.color == card3.color)&&(card1.color == card3.color)
        &&(card1.number != card2.number)&&(card2.number != card3.number)&&(card1.number != card3.number)
        &&(card1.shading == card2.shading)&&(card2.shading == card3.shading)&&(card1.shading == card3.shading)){
            return true;
    }
    else return false;
    return false;
}

function PrintCardToConsole(card_UI){
    console.log("Cards are: ");
    for ( let i = 0; i< card_UI.length; ++i){                    
        for (let j = 0 ; j < card_UI[i].length; ++j){
            console.log(card_UI[i][j].number,card_UI[i][j].color, card_UI[i][j].shape, card_UI[i][j].shading );        
        }
    }
    console.log("------------------------------------------");
}
// Delete 3 good cards that made a SET
function DeleteCard (chosed_Card,card_UI){
    for (let k = 0 ; k<chosed_Card.length ; k++) {
        for ( let i = 0; i< card_UI.length; ++i){                   
            for (let j = 0 ; j < card_UI[i].length; ++j){
                if ((card_UI[i][j].number == chosed_Card[k].number)
                    &&(card_UI[i][j].color == chosed_Card[k].color)
                    &&(card_UI[i][j].shading == chosed_Card[k].shading)
                    &&(card_UI[i][j].shape == chosed_Card[k].shape)){
                        card_UI[i].splice(j,1);
                    }
            }
        }
    }
} 

// Replace the wrong 3 cards selected
function ReplaceCard (chosed_Card,card_UI,card_deck) {
    for (let k = 0 ; k<chosed_Card.length ; k++) {
        for ( let i = 0; i< card_UI.length; ++i){                   
            for (let j = 0 ; j < card_UI[i].length; ++j){
                if ((card_UI[i][j].number == chosed_Card[k].number)
                    &&(card_UI[i][j].color == chosed_Card[k].color)
                    &&(card_UI[i][j].shading == chosed_Card[k].shading)
                    &&(card_UI[i][j].shape == chosed_Card[k].shape)&&(chosed_Card[k])){
                        card_UI[i][j] = PickOneCard(card_deck);
                    }
            }
        }
    }
}

//Drawing functions
function drawDiamond(ctx, number, color, shading, x, y, width=40, height = 40){ 
    if(number == 3)
        x -= 50;
    else if(number == 2)
        x -= 25;
    for(let i = 0; i<number; i++)
    {
        ctx.save();
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(x - width / 2, y + height / 2);
        ctx.lineTo(x, y + height);
        ctx.lineTo(x + width / 2, y + height / 2);
        ctx.closePath();
        ctx.strokeStyle = color;
        ctx.stroke()
        if(shading == 'solid')
        {
            ctx.fillStyle = color;
            ctx.fill();
            ctx.restore();

        }
        else if(shading == 'striped')
           drawStripes(ctx, color, x,y);                                     
        x += 50
    }
}
function drawOval(ctx, number, color, shading, x, y, width=40, height=70, radius=20){ 
    if(number == 3)
        x -= 50;
    else if(number == 2)
        x -= 25;
    for(let i=0; i<number; i++) 
    {
        ctx.beginPath();
        ctx.moveTo(x, y + radius);
        ctx.lineTo(x, y + height - radius);
        ctx.arcTo(x, y + height, x + radius, y + height, radius);
        ctx.lineTo(x + width - radius, y + height);
        ctx.arcTo(x + width, y + height, x + width, y + height-radius, radius);
        ctx.lineTo(x + width, y + radius);
        ctx.arcTo(x + width, y, x + width - radius, y, radius);
        ctx.lineTo(x + radius, y);
        ctx.arcTo(x, y, x, y + radius, radius);
        ctx.strokeStyle = color;
        ctx.stroke();
        if(shading == 'solid')
        {
            ctx.fillStyle = color;
            ctx.fill();
            ctx.restore();
        }
        else if(shading == 'striped')
        {
            ctx.save();
            ctx.beginPath();
            ctx.moveTo(x - width / 4 + 13, y + height / 4);
            ctx.lineTo(x + width / 4 + 28, y + height / 4);
            ctx.closePath();
            ctx.strokeStyle = color;
            ctx.stroke();
            ctx.moveTo(x - width / 2 + 20, y + height / 2);
            ctx.lineTo(x + width / 2 + 20, y + height / 2);
            ctx.closePath();
            ctx.strokeStyle = color;
            ctx.stroke();
            ctx.moveTo(x - width / 4 + 13, y + ( height * 3/4) );
            ctx.lineTo(x + width / 4 + 28, y + height * 3/4);
            ctx.closePath();
            ctx.strokeStyle = color;
            ctx.stroke();
        }
        x += 50;
    }
}

function drawStripes(ctx, color, x=140, y=60, width = 40, height = 40)
{ 
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(x - width / 4, y + height / 4);
    ctx.lineTo(x + width / 4, y + height / 4);
    ctx.closePath();
    ctx.strokeStyle = color
    ctx.stroke()
    ctx.moveTo(x - width / 2, y + height / 2);
    ctx.lineTo(x + width / 2, y + height / 2);
    ctx.closePath();
    ctx.strokeStyle = color
    ctx.stroke()
    ctx.moveTo(x - width / 4, y + ( height * 3/4) );
    ctx.lineTo(x + width / 4, y + height * 3/4);
    ctx.closePath();
    ctx.strokeStyle = color;
    ctx.stroke();
}

function drawSquiggle(ctx,  number, color, shading, x=110, y=80) 
{  
    if (number == 3) x-= 33;
    else if (number == 2) x -=10;
    else if (number == 1) x +=10; 
   for(let i=0; i<number; i++){
     ctx.beginPath();
      ctx.moveTo(x ,y);
      ctx.lineTo(x+10, y-10);
      ctx.lineTo(x+20, y);
      ctx.lineTo(x+30, y-10) ;
      ctx.lineTo(x+30, y+10);
      ctx.lineTo(x+20, y+20);
      ctx.lineTo(x+10, y+10);
      ctx.lineTo(x, y+20);
      ctx.closePath();
      ctx.strokeStyle = color;
      ctx.stroke()
      if(shading == 'solid')
      {
          ctx.fillStyle = color;
          ctx.fill();
          ctx.restore();
      }
      else if(shading == 'striped')
      {
          ctx.beginPath();
          ctx.moveTo(x+10, y-10);
          ctx.lineTo(x+10, y+10);
          ctx.strokeStyle = color;
          ctx.stroke();
          ctx.beginPath();
          ctx.moveTo(x+20, y);
          ctx.lineTo(x+20, y+20)
          ctx.strokeStyle = color;
          ctx.stroke();
          ctx.beginPath();
          ctx.moveTo(x+5, y-5);
          ctx.lineTo(x+5, y+15);
          ctx.strokeStyle = color;
          ctx.stroke();
          ctx.beginPath();
          ctx.moveTo(x+15, y-5);
          ctx.lineTo(x+15, y+15);
          ctx.strokeStyle = color;
          ctx.stroke();
          ctx.beginPath();
          ctx.moveTo(x+25, y-5);
          ctx.lineTo(x+25, y+15);
          ctx.strokeStyle = color;
          ctx.stroke();
      }
      x+= 45;
    }
}