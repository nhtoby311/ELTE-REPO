let mode = document.getElementById('mode');
let nameOfPlayer = document.getElementById('name');
let startGameBtn = document.getElementById('startGame');
let resetGameBtn = document.getElementById('resetGame');
let numberOfPlayer = document.getElementById('players');

startGameBtn.addEventListener('click',function(){
    localStorage.setItem("nameOfPlayer", nameOfPlayer.value);
    localStorage.setItem("mode", mode.value);
    localStorage.setItem("numberOfPlayer", numberOfPlayer.value);
    // if (mode.value == 'Competitive'){
    //     window.location = "CompetitiveMode.html";
    // } else {
    //     window.location = "PracticeMode.html";
    // }
    window.location = "Game.html";
});
