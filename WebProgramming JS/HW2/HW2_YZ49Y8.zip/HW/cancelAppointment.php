<?php
	session_start();
	$data = file_get_contents('data/users.json');
	$json_arr = json_decode($data, true);
	$arr_index = array();
	foreach ($json_arr as $key => $value)
	{
		if ($value['email'] == $_SESSION['user'])
		{
			$arr_index[] = $key;
		}
	}
	foreach ($arr_index as $i)
	{
		$json_arr[$i]['date'] = NULL;
		$json_arr[$i]['time_slot'] = NULL;
		$json_arr[$i]['free_slot'] = NULL;
		$json_arr[$i]['total_slot'] = NULL;

	}
	$json_arr = array_values($json_arr);
	file_put_contents('data/users.json', json_encode($json_arr));
	$_SESSION['date']=null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Cancel Appointment Page</title>
	<link href="https://fonts.googleapis.com/css?family=Hind:400,700" rel="stylesheet">
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />
	<link type="text/css" rel="stylesheet" href="css/style.css" />
</head>
<body>
	<div id="booking" class="section">
		<div class="topcorner">
		<?php if (!empty($_SESSION['user'])): ?>
			<p style="color: white">Welcome <?= $_SESSION['user'] ?>!</p>
			<a href="logout.php" class="btn btn-success" role="button" aria-pressed="true">Logout</a>	
        <?php else: ?>
			<a href="login.php" class="btn btn-success" role="button" aria-pressed="true">Login</a>	
			<a href="register.php" class="btn btn-warning" role="button" aria-pressed="true">Register</a>			
		<?php endif ?>
		</div>

		<div class="section-center">
			<div class="container">
				<div class="row">
					<div class="booking-form">
						<div class="form-header">
							<h1>Canceled Appointment</h1>
							<h3 style="color: white">Re-directing to homepage ...</h3>
						</div>					
					</div>
				</div>
			</div>
		</div>
	</div>
</body>
</html>
<script>setTimeout(function() { location.replace("index.php")},2000);</script>