<?php
	session_start();
	if (!isset($_SESSION['user'])){
		$_SESSION['user'] = null;
	}
	if ($_POST && !empty($_SESSION['user'])){ 
		$_SESSION['date'] = $_POST['date'];
		$_SESSION['time_slot'] = $_POST['time_slot'];
		$_SESSION['free_slot'] = $_POST['free_slot'];
		$_SESSION['total_slot'] = $_POST['total_slot'];
		$data = file_get_contents('data/users.json');
		$json_arr = json_decode($data, true);
		$arr_index = array();
		foreach ($json_arr as $key => $value)
		{
			if ($value['email'] == $_SESSION['user'])
			{
				$arr_index[] = $key;
			}
		}
		foreach ($arr_index as $i)
		{
			$json_arr[$i]['date'] = $_POST['date']; 
			$json_arr[$i]['time_slot'] = $_POST['time_slot'];
			$json_arr[$i]['free_slot'] = $_POST['free_slot'];
			$json_arr[$i]['total_slot'] = $_POST['total_slot'];	
		}
		$json_arr = array_values($json_arr);
		file_put_contents('data/users.json', json_encode($json_arr));
		header("Location: index.php");
		exit();
	} else if ($_POST && empty($_SESSION['user'])){
		$_SESSION['date'] = $_POST['date'];
		$_SESSION['time_slot'] = $_POST['time_slot'];
		$_SESSION['free_slot'] = $_POST['free_slot'];
		$_SESSION['total_slot'] = $_POST['total_slot'];
		header("Location: register.php");
		exit();
	}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Main Page</title>
	<link href="https://fonts.googleapis.com/css?family=Hind:400,700" rel="stylesheet">
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />
	<link type="text/css" rel="stylesheet" href="css/style.css" />
</head>
<body>
	<div id="booking" class="section">
		<div class="topcorner">
		<?php if (!empty($_SESSION['user'])): ?>
			<p style="color: white">Welcome <?= $_SESSION['user'] ?>!</p>
			<a href="logout.php" class="btn btn-success" role="button" aria-pressed="true">Logout</a>	
        <?php else: ?>
			<a href="login.php" class="btn btn-success" role="button" aria-pressed="true">Login</a>	
			<a href="register.php" class="btn btn-warning" role="button" aria-pressed="true">Register</a>			
		<?php endif ?>
		</div>
		<?php if (empty($_SESSION['date'])): ?>
			<div class="section-center">
				<div class="container">
					<div class="row">
						<div class="booking-form">
							<div class="form-header">
								<h1>Booking Page</h1>
							</div>
							<form method="POST" id="form">
								<div class="row">
									<div class="col-md-12">
										<div class="form-group">
											<span class="form-label">Date</span>
											<input class="form-control" type="date" name="date" required>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-4">
										<div class="form-group">
											<span class="form-label">Time Slot</span>
											<select class="form-control" name="time_slot">
												<option>00:00</option>
												<option>1:00</option>
												<option>2:00</option>
												<option>3:00</option>
												<option>4:00</option>
												<option>5:00</option>
												<option>6:00</option>
												<option>7:00</option>
												<option>8:00</option>
												<option>9:00</option>
												<option>10:00</option>
												<option>11:00</option>
												<option>12:00</option>
												<option>13:00</option>
												<option>14:00</option>
												<option>15:00</option>
												<option>16:00</option>
												<option>17:00</option>
												<option>18:00</option>
												<option>19:00</option>
												<option>20:00</option>
												<option>21:00</option>
												<option>22:00</option>
												<option>23:00</option>										
											</select>
											<span class="select-arrow"></span>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<span class="form-label">Free Slot</span>
											<select class="form-control" name="free_slot">
												<option>1</option>
												<option>2</option>
												<option>3</option>
												<option>4</option>
												<option>5</option>
											</select>
											<span class="select-arrow"></span>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<span class="form-label">Total Slot</span>
											<select class="form-control" name="total_slot">
												<option selected="selected">5</option>
											</select>
											<!-- <span class="select-arrow"></span> -->
										</div>
									</div>
								</div>
								<div class="form-btn">
									<?php if ($_SESSION['user'] != 'admin') : ?>
										<button class="submit-btn">Book This Date</button>
									<?php else: ?>
										<span class="form-label">List of Appointments: </span>
										<?php 
											$raw_persons = file_get_contents('data/users.json');
											$persons = json_decode($raw_persons, TRUE);
											foreach ($persons as $per) {
												echo "<br>";
												echo "<span style='color: white'>Name: ",$per['name'],"</span>";
												echo "<br>";
												echo "<span style='color: white'>Date: ",$per['date'],"</span>";
												echo "<br>";
												echo "<span style='color: white'>Free Slot: ",$per['free_slot'],"</span>";
												echo "<br>";
												echo "<span style='color: white'>Total Slot: ",$per['total_slot'],"</span>";
												echo "<br>";
											}											 
										?>
									<?php endif ?>	
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		<?php else: ?>
			<div class="section-center">
				<div class="container">
					<div class="row">
						<div class="booking-form">
							<div class="form-header">
								<h1>Booking Information</h1>
							</div>
							<form method="POST" id="form">
								<div class="row">
									<div class="col-md-12">
										<div class="form-group">
											<!-- <span class="form-label">Information</span> -->
											<div class="panel panel-default">
											<div class="panel-heading">
												<h3 class="panel-title">Your Appointment</h3>
											</div>
											<div class="panel-body">
												<?php 
													$raw_persons = file_get_contents('data/users.json');
													$persons = json_decode($raw_persons, TRUE);
													foreach ($persons as $per) {
														if ((strcmp($per['email'],$_SESSION['user'])==0)){
															echo "Name: ";
															echo $per['name'];
															echo "<br>";
															echo "Date: ";
															echo $per['date'];
															echo "<br>";
															echo "Free Slot: ";
															echo $per['free_slot'];
															echo "<br>";
															echo "Total Slot: ";
															echo $per['total_slot'];
														}
													} 
												?>
											</div>
											</div>
										</div>
									</div>
								</div>								
								<div class="form-btn">
									<input type="button" class="submit-btn" id="cancelBtn" value="Cancel This Booking" onClick="window.location = 'cancelAppointment.php'">									
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		<?php endif ?>
	</div>
</body>
</html>