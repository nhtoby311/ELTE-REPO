<?php
    session_start();
    $errors = []; 
    if ($_POST){ 
        if (empty($_POST['email'])){
            $errors[]='The "Email" field is required';
        }
        if (empty($_POST['password'])){
            $errors[]='The "Password" field is required';
        }

        $checkIfEmailExists = false;
        if (count($errors) === 0) {
            $person = [
                'email' => $_POST['email'],
                'password' => $_POST['password'],
            ];
            $raw_persons = file_get_contents('data/users.json');
            $persons = json_decode($raw_persons, TRUE);
            if ((strcmp($_POST['email'],"admin@nemkovid.hu")===0)&&(strcmp($_POST['password'],"admin")===0)){
                $_SESSION['user'] = "admin";
                header("Location: index.php");
                exit();
            } else foreach ($persons as $per) {
                if (strcmp($per['email'],$person['email'])==0){
                    if (strcmp($per['password'],$person['password'])==0){
                        $checkIfEmailExists = true;
                        $_SESSION['date'] = $per['date'];
                    }
                } 
            } 
            if ($checkIfEmailExists == true){
                $_SESSION['user'] = $_POST['email'];
                header("Location: index.php");
                exit();
            } else {
                $errors[]='User email or password is wrong ! Please try again !';
            }
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login Page</title>
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="css/style2.css">
</head>
<body>
    <?php if (count($errors)>0): ?>
        <ul>
            <?php foreach ($errors as $error): ?>
            <li><?= $error ?></li> 
            <?php endforeach ?>
        </ul>
    <?php endif ?>
    <section class="sign-in">
        <div class="container">
            <div class="signin-content">
                <div class="signin-image">
                    <figure><img src="img/signin-image.jpg" alt="sing up image"></figure>
                    <a href="register.php" class="signup-image-link">Create an account</a>
                </div>

                <div class="signin-form">
                    <h2 class="form-title">Login</h2>
                    <form method="POST" class="register-form" id="login-form">
                        <div class="form-group">
                            <label for="email"><i class="zmdi zmdi-email"></i></label>
                            <input type="text" name="email" placeholder="Your Email" value="<?php if (count($errors)>0){echo $_POST['email'];} ?>">
                        </div>
                        <div class="form-group">
                            <label for="your_pass"><i class="zmdi zmdi-lock"></i></label>
                            <input type="password" name="password" id="your_pass" placeholder="Password" value="<?php if (count($errors)>0){echo $_POST['password'];} ?>">
                        </div>
                        <div class="form-group form-button">
                            <input type="submit" name="signin" id="signin" class="form-submit" value="Log in"/>
                        </div>
                    </form>                    
                </div>
            </div>
        </div>
    </section>

</div>
<script src="vendor/jquery/jquery.min.js"></script>
<script src="js/main.js"></script>
</html>