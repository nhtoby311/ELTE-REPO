<?php
    session_start();
    $errors = []; 
    if ($_POST){ 
        if (empty($_POST['name'])){
            $errors[]='The "Name" field is required';
        }
        if (empty($_POST['ssn'])){
            $errors[]='The "SSN" field is required';
        } else if (!is_numeric($_POST['ssn'])){
            $errors[]='The "SSN" should be digit only';
        }
        if (empty($_POST['address'])){
            $errors[]='The "Address" field is required';
        }
        if (empty($_POST['email'])){
            $errors[]='The "Email" field is required';
        }
        if (empty($_POST['password'])){
            $errors[]='The "Password" field is required';
        }
        if (empty($_POST['re-password'])){
            $errors[]='The "Re-enter Password" field is required';
        } 
        if (strcmp($_POST['password'],$_POST['re-password']) !== 0){
            $errors[]='Password should match';
        }
        $checkIfEmailExists = false;
        if (count($errors) === 0) {
            $person = [
                'email' => $_POST['email'],
                'password' => $_POST['password'],
                'name' => $_POST['name'],
                'date' => $_SESSION['date'],
                'time_slot' => $_SESSION['time_slot'],
                'free_slot' => $_SESSION['free_slot'],
                'total_slot' => $_SESSION['total_slot'],
            ];

            $raw_persons = file_get_contents('data/users.json');
            $persons = json_decode($raw_persons, TRUE);
            foreach ($persons as $per) {
                if (strcmp($per['email'],$person['email'])==0){
                    $errors[] = "Email address is already in use";
                    $checkIfEmailExists = true;
                }
            } 
            if ($checkIfEmailExists == false){
                $persons[] = $person;
                file_put_contents('data/users.json', json_encode($persons));
                header("Location: login.php");
                exit();
            }
        } 
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Register Page</title>
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="css/style2.css">
</head>
<body>
    <?php if (count($errors)>0): ?>
        <ul>
            <?php foreach ($errors as $error): ?>
            <li><?= $error ?></li> 
            <?php endforeach ?>
        </ul>
    <?php endif ?>
    <section class="signup">
        <div class="container">
            <div class="signup-content">

            
                <div class="signup-form">
                    <h2 class="form-title">Sign up</h2>
                    <form method="POST" class="register-form" id="register-form">
                        <div class="form-group">
                            <label for="name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                            <input type="text" name="name" id="name" placeholder="Your Full Name" value="<?php if (count($errors)>0){echo $_POST['name'];} ?>">
                        </div>
                        <div class="form-group">
                            <label for="SSN"><i class="zmdi zmdi-face"></i></label>
                            <input name="ssn" placeholder="Your SSN" value="<?php if (count($errors)>0){echo $_POST['ssn'];} ?>">
                        </div>
                        <div class="form-group">
                            <label for="address"><i class="zmdi zmdi-menu"></i></label>
                            <input name="address" placeholder="Your Address" value="<?php if (count($errors)>0){echo $_POST['address'];} ?>">
                        </div>
                        <div class="form-group">
                            <label for="email"><i class="zmdi zmdi-email"></i></label>
                            <input type="email" name="email" placeholder="Your Email" value="<?php if (count($errors)>0){echo $_POST['email'];} ?>">
                        </div>
                        <div class="form-group">
                            <label for="pass"><i class="zmdi zmdi-lock"></i></label>
                            <input type="password" name="password" id="pass" placeholder="Password" value="<?php if (count($errors)>0){echo $_POST['password'];} ?>">
                        </div>
                        <div class="form-group">
                            <label for="re-pass"><i class="zmdi zmdi-lock-outline"></i></label>
                            <input type="password" name="re-password" id="re_pass" placeholder="Repeat your password" value="<?php if (count($errors)>0){echo $_POST['re-password'];} ?>">
                        </div>                        
                        <div class="form-group form-button">
                            <input type="submit" name="signup" id="signup" class="form-submit" value="Register"/>
                        </div>
                    </form>
                </div>
                <div class="signup-image">
                    <figure><img src="img/signup-image.jpg" alt="sing up image"></figure>
                    <a href="login.php" class="signup-image-link">I am already member</a>
                </div>
            </div>
        </div>
    </section>

</div>
<script src="vendor/jquery/jquery.min.js"></script>
<script src="js/main.js"></script>
</html>